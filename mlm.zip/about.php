<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>MLM</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/copy.css" rel="stylesheet">
    <link href="css/about.css" rel="stylesheet">
    <style>
        p {
            font-size: 1.2rem;
        }

        strong {
            font-size: 1.3rem;
        }



        .card {
            border-radius: 0px;
            box-shadow: none;
        }
    </style>
</head>

<body data-bs-spy="scroll" data-bs-target=".navbar" data-bs-offset="50">
    <script src="script.js"></script>

    <script>
        $('input').on('change', function() {
            $('body').toggleClass('blue');
        });
    </script>

    <!-- Navbar -->
    <?php include("nav-bar.php"); ?>
    <!-- Navbar -->

    <!-- Modal -->
    <?php include("modal.php"); ?>
    <!-- Modal -->

    <!-- Modal -->
    <script src="modal.js"></script>
    <!-- Modal -->

    <!-- Hero Section -->
    <section class="container-fluid">
        <!--  Start -->
        <div class="container-fluid p-0">
            <div class="container-fluid d-flex align-items-center justify-content-end w-100 p-0">
                <div class="row align-items-end d-flex w-100 promo card-holder">
                    <div class="col-x p-3">
                        <h1 class="pb-3 d-inline">We Are Constantly </h1>
                        <h1 class="text-info d-inline">Innovating And Staying Up-To-Date </h1>
                        <h1 class="d-inline">On The Latest Trends In Our Industry.</h1>
                    </div>
                    <div class="col-x p-3">
                        <p>At Metaveos MLM Solution, we are committed to delivering the best possible MLM software, solutions, and customer experience.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero End -->


    <!-- About -->
    <section id="about">
        <div class="container-fluid pb-3 p-0 " id="imaga">
            <img src="cover-img.jpg" class="about-main-img" alt="">
        </div>
        <div class="container-fluid d-flex about-section-data promo justify-content-center align-items-center">
            <div class="about-sub-section-1 d-flex justify-content-end">
                <img src="about/About-us.png" class="about-sub-section-1-img" alt="">
            </div>
            <div class="about-sub-section-2">
                <p class="text-info fw-bold mb-3">About Us</p>
                <h2 class="mt-3 d-inline fw-medium">Our Commitment To</h2>
                <h2 class="fw-bold"> Quality & Customer Satisfaction</h2>
                <hr class="w-50 mt-2 d-inline-block">
                <hr class="hr ml-3 d-inline-block">
                <div class="about-data">
                    <p class="p-3 pl-0">At Metaveos MLM Solution, we are passionate about helping multi-level marketing companies reach their full potential.</p>
                    <p class="p-3 pl-0">With our state-of-the-art software platform, we provide the tools and support that MLM businesses need to succeed.</p>
                    <p class="p-3 pl-0">Our platform is designed to streamline operations, improve efficiency, and drive growth for our clients.</p>
                    <p class="p-3 pl-0">From sales and marketing to customer relationship management, we have all the features and functionality you need to thrive.</p>
                    <p class="p-3 pl-0">Our team of expert developers and support staff are here to help you every step of the way.</p>
                </div>
            </div>
        </div>
    </section>
    <!-- About End -->
    <section>
        <div class="container-fluid p-0">
            <div class="container-fluid mt-3 p-3">
                <h2 class="mt-3 text-center fw-bold">We Work Closely With Our Clients</h2>
                <div class="logo d-flex flex-wrap align-items-center justify-content-around">
                    <img src="about/Portfolio_logo 1.png" class="about-logos" alt="">
                    <img src="about/Portfolio_logo 2.png" class="about-logos" alt="">
                    <img src="about/Portfolio_logo 3.png" class="about-logos" alt="">
                    <img src="about/Portfolio_logo 4.png" class="about-logos" alt="">
                    <img src="about/Portfolio_logo 5.png" class="about-logos" alt="">
                </div>
            </div>
            <div class="container-fluid bg-light2 mt-5 p-3">
                <p class="text-info text-center fw-bold mb-3 mt-3 p-3">Mission & Value</p>
                <h2 class="mt-3 text-center fw-bold">Why Do We Do What We Do</h2>
                <div class="mission d-flex flex-column align-items-center">
                    <p class="mission-text p-3 text-center pl-0">At Metaveos MLM Solution, we believe that every business has the potential to succeed and grow. That's why we are dedicated to providing the best MLM software platform on the market.</p>
                    <p class="mission-text p-3 text-center pl-0">Our platform is designed to streamline operations, improve efficiency, and drive growth for our clients.</p>
                    <p class="mission-text p-3 text-center pl-0">We believe that by helping our clients succeed, we can create value for everyone involved. That's our promise to you.</p>
                    <a onclick="modal()" class=" btn-lg btn-info text-center w-fit mt-3 h2" id="">
                        <span class="text-center fw-bold">Request a demo today</span>
                    </a>
                </div>
            </div>
            <div class="container-fluid mt-5 p-3">
                <p class="text-info text-center fw-bold mb-3 mt-3 p-3">Why Choose Us</p>
                <h2 class="mt-3 text-center fw-bold">Why Our Company Is Right Fit For You?</h2>
                <div class="mission d-flex justify-content-center align-items-center flex-wrap">
                    <div class="bg-light3 card rounded m-3 " style="width: 20rem;">
                        <div class="card-body d-flex flex-column w-100 pt-4 justify-content-start align-items-start">
                            <img class="card-img mt-0 p-3" src="about/Satisfaction Icon.png" alt="Card image cap">
                            <h6 class="card-title m-0 ">Matrix MLM Software</h6>
                        </div>
                        <div class="card-body pt-0 pl-3 pr-3 pb-5">
                            <p>At Metaveos MLM Solution, We Are Dedicated To Delivering The Highest Quality Software And Support To Our Clients. That's Why We Have A Proven Record Of 100% Satisfied Clients. We Are Confident That Our Platform Will Meet The Needs Of Your Business And Help You Succeed.</p>
                        </div>
                    </div>
                    <div class="bg-light3 card rounded m-3 " style="width: 20rem;">
                        <div class="card-body d-flex flex-column w-100 pt-4 justify-content-start align-items-start">
                            <img class="card-img mt-0 p-3" src="about/Support Icon.png" alt="Card image cap">
                            <h6 class="card-title m-0 ">Expert-Developers & Support Staffs</h6>
                        </div>
                        <div class="card-body pt-0 pl-3 pr-3 pb-5">
                            <p>At Metaveos MLM Solution, We Are Dedicated To Delivering The Highest Quality Software And Support To Our Clients. That's Why We Have A Proven Record Of 100% Satisfied Clients. We Are Confident That Our Platform Will Meet The Needs Of Your Business And Help You Succeed.</p>
                        </div>
                    </div>
                    <div class="bg-light3 card rounded m-3 " style="width: 20rem;">
                        <div class="card-body d-flex flex-column w-100 pt-4 justify-content-start align-items-start">
                            <img class="card-img mt-0 p-3" src="about/User Friendly Icon.png" alt="Card image cap">
                            <h6 class="card-title m-0 ">Matrix MLM Software</h6>
                        </div>
                        <div class="card-body pt-0 pl-3 pr-3 pb-5">
                            <p>At Metaveos MLM Solution, We Are Dedicated To Delivering The Highest Quality Software And Support To Our Clients. That's Why We Have A Proven Record Of 100% Satisfied Clients. We Are Confident That Our Platform Will Meet The Needs Of Your Business And Help You Succeed.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>





    <!-- Footer Start -->
    <!-- Footer -->
    <?php include("footer.php"); ?>
    <!-- Footer -->

    <!-- Footer End -->
    <script src="faq.js"></script>

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top" id="back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
    <script src="lib/isotope/isotope.pkgd.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>