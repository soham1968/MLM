<div class="container-fluid h-50 mt-5 p-0 d-flex align-items-center">
    <div class="row align-items-center d-flex w-100 about-div promo card-holder">
        <div class="about-img-faq d-flex justify-content-center flex-column">
            <p class="text-info text-left fw-bold">FAQs</p>
            <h2>Answering Your Most Asked Questions</h2>
            <object data="assets/FAQs-pana 1.svg" class="w-100" type=""></object>
        </div>

        <div class="about-text-faq">
            <div class="accordion" id="accordionExample">
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            <strong>What features does your MLM software offer?</strong>
                        </button>
                    </h2>
                    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <span>Our MLM software offers a wide range of features to support your business. Some of the key features include: 1. Lead capture & management, 2. Genealogy tracking, Order processing and fulfillment, 4. Commission tracking.
                                <br><br> This is just a small sample of the many features our MLM software offers. We are constantly updating and improving our software to meet the needs of our users, so be sure to check back often to see what's new.</span>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingTwo">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            <strong>How easy is it to onboard new members and manage my downline?</strong>
                        </button>
                    </h2>
                    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <span>Our MLM software makes it easy to onboard new members and manage your downline. We have a user-friendly interface that allows you to quickly add new members, track their progress, and access important information about your organization.</span>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingThree">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            <strong>Can I track and analyze my sales and commissions with your software?</strong>
                        </button>
                    </h2>
                    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <span>Yes, our MLM software offers advanced tracking and analysis tools to help you monitor your sales and commissions. You can view real-time data on your earnings, as well as track your progress over time. Our software also includes customizable reports and graphs, so you can see how your business is performing and identify areas for improvement.</span>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingThree">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            <strong>Can I customize the look and feel of the software to match my brand?</strong>
                        </button>
                    </h2>
                    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <span>Yes, our MLM software allows you to customize the look and feel of the software to match your brand. We also offer the ability to add your own logos and branding assets, so you can fully customize the software to reflect your brand identity. If you have any specific customization needs, our support team would be happy to assist you..</span>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingThree">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            <strong>Do you offer any training or support to help me get started with the software?</strong>
                        </button>
                    </h2>
                    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <span>Yes, we offer a variety of training and support options to help you get started with our MLM software. We have a comprehensive knowledge base that includes articles, tutorials, and video guides to help you learn how to use the software. We also offer live support via email and chat, so you can get help whenever you need it.</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>