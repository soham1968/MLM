<div class="container-fluid h-25 mt-5 d-flex align-items-center promo " id="promo">
    <div class="container-fluid pt-5 pb-5" id="promo-sub1">
        <h2 class="text-white">
            Ready to boost your network marketing business with our software solutions?
        </h2>
        <p class="text-white pt-3 pb-3">
            We offer a suite of software solutions for network marketing businesses to grow their business
            beyond boundaries.
        </p>
        <a onclick="modal()" class=" btn-lg btn-secondary d-flex w-max mt-3 align-items-center h2" id=""><i class="bi bi-calendar3 pr-2"></i>
            <span>Schedule Your Free Demo</span>
        </a>
    </div>
    <div class="container-fluid p-3" id="promo-sub2">
        <img src="assets/Career progress-pana 1.png" class="w-100" alt="">
    </div>
</div>