<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>MLM</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/copy.css" rel="stylesheet">
</head>

<body data-bs-spy="scroll" data-bs-target=".navbar" data-bs-offset="50">


    <!-- Modal -->
    <script src="modal.js"></script>
    <!-- Modal -->
    <script src="script.js"></script>

    <script>
        $('input').on('change', function() {
            $('body').toggleClass('blue');
        });
    </script>

    <!-- Navbar -->
    <?php include("nav-bar.php"); ?>
    <!-- Navbar -->
    <!-- Modal -->
    <?php include("modal.php"); ?>
    <!-- Modal -->

    <!-- Hero Section -->
    <section id="top-content">
        <!--  Start -->
        <div class="container-fluid p-0">
            <div class="container-fluid d-flex align-items-center justify-content-center p-0">
                <div class="row d-flex align-items-center w-100 promo card-holder">
                    <div class="col-xl">
                        <h1 class="text-white pb-3">Streamline Operations And Increase Profits With Our Matrix MLM Software</h1>
                        <p id="para" class="pb-3 text-white">From customer management and commission tracking to sales reporting and marketing materials, our advanced software has everything you need to succeed.</p>
                        <a href="#" onclick="modal()" class="start-btn py-2-75 "><span class="text-center fw-bold">Claim Your
                                FREE
                                Demo</span></a>
                    </div>
                    <div class="col-xl sub-card-holder">
                        <object data="assets/Team work-pana 1.svg" class="w-100" type=""></object>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero End -->


    <!-- About -->
    <section id="about">
        <div class="container-fluid p-0">

            <div class="row align-items-center d-flex w-100 promo about-div">
                <div class="d-flex justify-content-center about-img">
                    <img src="assets/Binary Icon.png" class="w-50" alt="">
                </div>

                <div class="about-text">
                    <h2 class="pb-2">How Does a Matrix MLM Works?</h2>
                    <p class="">The matrix structure allows affiliates to earn residual income from the sales of their downline members, as they continue to earn commissions on the sales of their team even if they are no longer activel recruiting.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- About End -->

    <!-- Marketing Section -->

    <section>
        <?php include("subhero.php"); ?>
        <!-- subhero -->

        <div class="container-fluid p-0 h-50  mt-5 d-flex align-items-center flex-column" id="products">
            <div class="row align-items-center d-flex justify-content-center w-100  promo about-div-reverse">
                <div class="d-flex first-product-img about-img-reverse">
                    <object data="assets/user friendly.svg" class="w-100" type=""></object>
                </div>

                <div class="about-text-reverse">
                    <h2 class="pb-3">User Friendly</h2>
                    <p class="">Our MLM software is designed to make managing and growing your business simple and stress-free. With a user-friendly interface and straightforward navigation, you'll be able to easily track and manage your customers, commissions, and sales.</p>
                </div>
            </div>

            <div class="row align-items-center d-flex w-100 promo about-div-reverse justify-content-center">
                <div class="about-text-reverse">
                    <h2 class="pb-3">Fast, Secure and Reliable</h2>
                    <p class="">Our fast, secure, and reliable MLM software ensures that your business runs smoothly and your data is safe. With advanced technology and robust security measures, you can trust that your operations will be efficient and your information will be protected.</p>
                </div>
                <div class="about-img-reverse d-flex justify-content-center">
                    <object data="assets/Secure.svg" class="w-100" type=""></object>
                </div>


            </div>
        </div>
    </section>

    <!-- Marketing Section -->


    <!-- Review Section -->
    <section>
        <!-- Carousel -->
        <?php include("carousel.php"); ?>
        <!-- Carousel -->

        <!-- faq -->
        <?php include("faq.php"); ?>
        <!-- faq -->

        <!-- demo -->
        <?php include("demo.php"); ?>
        <!-- demo -->


    </section>

    <!-- Review End -->



    <!-- Footer Start -->
    <!-- Footer -->
    <?php include("footer.php"); ?>
    <!-- Footer -->

    <!-- Footer End -->
    <script src="faq.js"></script>

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top" id="back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
    <script src="lib/isotope/isotope.pkgd.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>