<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>MLM</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/copy.css" rel="stylesheet">
    <link href="css/contact.css" rel="stylesheet">
    <style>

    </style>
</head>

<body data-bs-spy="scroll" data-bs-target=".navbar" data-bs-offset="50">
 

    <!-- Modal -->
    <script src="modal.js"></script>
    <!-- Modal -->
    <script src="script.js"></script>

    <script>
        $('input').on('change', function() {
            $('body').toggleClass('blue');
        });
    </script>

    <!-- Navbar -->
    <?php include("nav-bar.php"); ?>
    <!-- Navbar -->
   <!-- Modal -->
   <?php include("modal.php"); ?>
    <!-- Modal -->
    <section id="Contact">
        <div class="container-fluid m-0 d-flex flex-column align-items-center main-div">
            <h2 class="text-center p-3">Contact Us</h2>
            <h4 class="text-center mb-5">If you need to get in touch with us for any reason, our contact page has everything you need.</h4>
            <div class="container-fluid h-100 w-100 p-0 d-flex  align-content-center justify-content-center">
                <div class="row align-items-start d-flex " id="contact-sec">
                    <div class="d-flex justify-content-around bg-info me-3 rounded-4 p-2 flex-column contact-sub-sec h-100">
                        <div class="con-text d-flex flex-column justify-content-center sub-con-1">

                            <div class="sub-head">
                                <i class="fas fa-home me-3"></i>
                                <h6 class="text-white "> Odisha, Bhubaneswar 751006, India</h6>
                            </div>
                            <div class="sub-head">
                                <i class="fas fa-envelope me-3"></i>
                                <h6 class="text-white">
                                    metaveos@gmail.com
                                </h6>
                            </div>
                            <div class="sub-head">
                                <i class="fas fa-envelope me-3"></i>
                                <h6 class="text-white">
                                    metaveos@gmail.com
                                </h6>
                            </div>
                        </div>
                        <div class="map pr-2 pb-2 pl-2 sub-con-2">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d3742.673084433656!2d85.85018442528175!3d20.2723885714983!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1smetaveos%20consultancy%20pvt%20ltd!5e0!3m2!1sen!2sin!4v1673083550147!5m2!1sen!2sin" class="w-100 h-100 rounded-4" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                    <!-- 👻 -->
                    <div class=" h-100 pt-3 pb-3 pl-3 contact-sub-sec">
                        <form>
                            <div class="mb-3 pb-3">
                                <label for="name" class="form-label">Full Name</label>
                                <input type="text" class="form-control" id="name" placeholder="Full Name">
                            </div>
                            <div class="mb-3 pb-3">
                                <label for="exampleInputEmail1" class="form-label">Email address</label>
                                <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Mail-Id" aria-describedby="emailHelp">
                            </div>
                            <div class="mb-3 pb-3">
                                <label for="number" class="form-label">Phone Number</label>
                                <input type="number" class="form-control" placeholder="Mobile Number" id="number">
                            </div>
                            <div class="mb-3 pb-3">
                                <label class="form-label" for="exampleCheck1">Message</label>
                                <!-- <input type="text-area" class="form-control" placeholder="Your Message" id="exampleCheck1"> -->
                                <textarea name="message" class="form-control" id="message" placeholder="Your Message" cols="5" rows="2"></textarea>
                            </div>
                            <button type="submit" class="btn-lg w-50 btn-primary send-msg">Send Message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <!-- Footer Start -->
    <!-- Footer -->
    <?php include("footer.php"); ?>
    <!-- Footer -->

    <!-- Footer End -->
    <script src="faq.js"></script>

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top" id="back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
    <script src="lib/isotope/isotope.pkgd.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>