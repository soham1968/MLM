    <!-- Navbar -->
    <div class="container-fluid sticky-top  bg-light-radial shadow-sm pl-0 pr-0 pe-lg-0" id="nav-head">
        <nav class="navbar navbar-expand-lg  bg-light-radial navbar-dark py-3 py-lg-2">
            <a href="index.html" class="navbar-brand">
                <img src="assets/MLM LOGO 2 2.png" id="nav-light-logo" class="nav-img" alt="">
                <img src="assets/mlm png.png" id="nav-dark-logo" style="display: none;" class="nav-img" alt="">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="fa fa-bars" id="toggle-btn"></span>
            </button>
            <div class="collapse navbar-collapse  align-items-center" id="navbarCollapse">
                <div class="navbar-nav ms-auto py-0">

                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a href="index.php" class="nav-heads nav-item nav-link active" id="nav-dark-head">Home</a>
                        </li>
                        <li class="nav-item">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" id="nav-dark-head2">
                                Our Products </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="binary.php"> Binary</a></li>
                                <li><a class="dropdown-item" href="unilevel.php"> Unilevel</a></li>
                                <li><a class="dropdown-item" href="matrix.php"> Matrix</a></li>
                            </ul>
                        </li>
                        <a href="about.php" class="nav-heads nav-item nav-link" name="nav-link" id="nav-dark-head1">About
                            Us</a>
                        </li>

                        <li class="nav-item">
                            <a href="contact.php" class="nav-heads nav-item nav-link" name="nav-link" id="nav-dark-head3">Contact
                                Us</a>
                        </li>
                        <li class="nav-item">
                            <a onclick="modal()" class="nav-item nav-link text-black px-5 py-2 ms-3 d-lg-block rounded-3" id="nav-dark-head4"><span class="fw-bold">Book a Free Demo</span>
                            </a>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>
    </div>
    <!-- Navbar -->