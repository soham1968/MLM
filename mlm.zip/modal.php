<!-- Modal -->
<div class="">
    <div id="id01" class="w3-modal p-0">
        <div class="w3-modal-content w3-card-4 w3-animate-zoom" style="max-width:600px">

            <div class="w3-center"><br>
                <span onclick="document.getElementById('id01').style.display='none'" class="w3-button-close me-2 mt-2 w3-xlarge w3-display-topright" title="Close Modal">&times;</span>
            </div>

            <form class="w3-container " action="/action_page.php">
                <div class="w3-section ">
                    <label><b>Full Name</b></label>
                    <input class="w3-input w3-border" type="text" placeholder="Full Name" name="name" required>
                    <label><b>Email</b></label>
                    <input class="w3-input w3-border" type="email" placeholder="Mail-Id" name="mail" required>
                    <label><b>Phone Number</b></label>
                    <input class="w3-input w3-border" type="number" placeholder="Phone Number" name="number" required>
                    <label><b>Select Product</b></label>
                    <select class="w3-input w3-border" aria-label="Default select example">
                        <option selected disabled>Select</option>
                        <option value="" class="lala" onmouseenter="haha()" id="form-select-option">Binary MLM Software</option>
                        <option value="" class="form-select-option">Unilevel MLM Software</option>
                        <option value="" class="form-select-option">Matrix MLM Software</option>
                        <option value="" class="form-select-option">Customised Software</option>
                    </select>

                    <button class="w3-button w3-block w3-teal w3-section w3-padding" type="submit">Send</button>
                    <!-- <input class="w3-check w3-margin-top" type="checkbox" checked="checked"> Remember me -->
                </div>
            </form>

        </div>
    </div>
</div>
<!-- Modal ends -->