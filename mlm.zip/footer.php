<footer class=" container-fluid position-relative text-lg-start bg-dark mt-0 h-100 py-6">
    <div class="container text-md-start">
        <!-- Grid row -->
        <div class="row mt-3 d-flex justify-content-around" id="foot">
            <!-- Grid column -->
            <div class="footer-sub col-md-5 col-lg-4 col-xl-3  mb-4">
                <!-- Content -->
                <div class="footer-icon pb-3">
                    <img src="assets/MLM LOGO 2 2.png" alt="">
                </div>
                <p class="text-white">
                    Here you can use rows and columns to organize your footer content. Lorem ipsum
                    dolor sit amet, consectetur adipisicing elit.
                </p>
                <div class="d-flex justify-content-start">
                    <a class="btn btn-lg btn-primary btn-lg-square rounded-0" href="#"><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-lg btn-primary btn-lg-square rounded-0" href="#"><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-lg btn-primary btn-lg-square rounded-0" href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a class="btn btn-lg btn-primary btn-lg-square rounded-0" href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
            <!-- Grid column -->

            <!-- Grid column -->
            <div class="footer-sub col-md-3 col-lg-2 col-xl-3 mb-4">
                <!-- Links -->
                <h5 class=" fw-bold mb-4 text-white">Our Products</h5>

                <a href="binary.php" class="text-reset ">
                    <p class="text-white p-1">Binary MLM Software ROI/Referral</p>
                </a>


                <a href="unilevel.php" class="text-reset text-white">
                    <p class="text-white p-1">Unilevel MLM Software ROI/Referral</p>
                </a>


                <a href="matrix.php" class="text-reset text-white">
                    <p class="text-white p-1">Matrix MLM Software ROI/Referral</p>
                </a>


            </div>
            <!-- Grid column -->



            <!-- Grid column -->
            <div class="footer-sub col-md-4 col-lg-3 col-xl-3 mb-md-0 mb-4 ">
                <!-- Links -->
                <!-- <h6 class="text-uppercase fw-bold mb-4 text-white">Our Address</h6>

                <p class="text-white"><i class="fas fa-home me-3"></i> Odisha, Bhubaneswar 751006, India</p>
                <p class="text-white">
                    <i class="fas fa-envelope me-3"></i>
                    metaveos@gmail.com
                </p>
                <p class="text-white"><i class="fas fa-phone me-3"></i> + 01 234 567 88</p>
                <p class="text-white"><i class="fas fa-print me-3"></i> + 01 234 567 89</p> -->
                <h5 class="fw-bold mb-4 text-white">Our Address</h5>
                <div class="sub-head">
                    <i class="fas fa-home  me-3"></i>
                    <h6 class="text-white "> Odisha, Bhubaneswar 751006, India</h6>
                </div>
                <div class="sub-head">
                    <i class="fas fa-envelope me-3"></i>
                    <h6 class="text-white">
                        metaveos@gmail.com
                    </h6>
                </div>
                <div class="sub-head">
                    <i class="fas fa-envelope me-3"></i>
                    <h6 class="text-white">
                        metaveos@gmail.com
                    </h6>
                </div>
            </div>
            <!-- Grid column -->
        </div>
        <!-- Grid row -->
    </div>
    <!-- Section: Links  -->

    <!-- Copyright -->

    <!-- Copyright -->
</footer>