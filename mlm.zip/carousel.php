<div class="container-fluid mt-5 d-flex flex-column justify-content-center align-items-center" id="client">
    <h2 class="text-center text-black p-2">See What Our Clients Are Saying</h2>
    <div class="contain">
        <input type="radio" name="slider" id="item-1" checked>
        <input type="radio" name="slider" id="item-2">
        <input type="radio" name="slider" id="item-3">
        <div class="carousel-cards">
            <label class="carousel-card pl-3  pr-3" for="item-1" id="song-1">
                <div class="stars">
                    <img src="assets/Stars.png" class="w-25" alt="">
                </div>
                <p class="text-center">Metaveos MLM Solution has revolutionized the way our company does business. The customer support team is always quick to respond and resolve any issues we have. We highly recommend Metaveos MLM Solution to any company looking to streamline its operations.
                </p>
                <div class="card-bottom d-flex justify-content-start align-items-center">
                    <img src="img/Testimonial 1.jpg" alt="song" class="carousel-img w-auto responsive">
                    <div class="carousel-card-info text-black">
                        <h5>Gayatri Desai</h5>
                    </div>
                </div>

            </label>
            <label class="carousel-card pl-3 pr-3" for="item-2" id="song-2">
                <div class="stars">
                    <img src="assets/Stars.png" class="w-25" alt="">
                </div>
                <p class="text-center pl-2 pr-2">We have been using Metaveos MLM Solution for the past year and have seen a significant increase in sales and customer satisfaction. The team at Metaveos MLM Solution is knowledgeable and always willing to help with any questions or concerns we have. We are extremely happy with our decision to partner with them.
                </p>
                <div class="card-bottom d-flex justify-content-start align-items-center ">
                    <img src="img/Testimonial 2.jpg" alt="song" class="carousel-img  responsive">
                    <div class="carousel-card-info text-black">
                        <h5>Prakash Shinde</h5>
                    </div>
                </div>

            </label>
            <label class="carousel-card pl-3 pr-3" for="item-3" id="song-3">
                <div class="stars">
                    <img src="assets/Stars.png" class="w-25" alt="">
                </div>
                <p class="text-center pl-2 pr-2">Since implementing Metaveos MLM Solution, we have seen a dramatic improvement in our ability to track and manage our sales and commissions. We highly recommend Metaveos MLM Solution to any MLM company looking to take their business to the next level.
                </p>
                <div class="card-bottom d-flex justify-content-start align-items-center">
                    <img src="img/Testimonial 3.jpg" alt="song" class="carousel-img  responsive">
                    <div class="carousel-card-info  text-black">
                        <h5>Rajat Sharma</h5>
                    </div>
                </div>
            </label>
            <!-- <label class="carousel-card pl-3 pr-3" for="item-4" id="song-4">
                <div class="stars d-flex justify-content-start ">
                    <img src="assets/211824_star_icon 1.png" class="star-img" alt="">
                    <img src="assets/211824_star_icon 1.png" class="star-img" alt="">
                    <img src="assets/211824_star_icon 1.png" class="star-img" alt="">
                    <img src="assets/211824_star_icon 1.png" class="star-img" alt="">
                    <img src="assets/211824_star_icon 1.png" class="star-img" alt="">
                </div>
                <p class="text-center pl-2 pr-2">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos
                    dolores
                    ipsum, doloribus quam maiores amet hic doloremque nemo? Ipsum eos aliquid dolore, ipsam aut
                    optio eum laboriosam obcaecatie.</p>
                <div class="card-bottom d-flex justify-content-start align-items-center">
                    <img src="img/Testimonial 4.jpg" alt="song" class="carousel-img  responsive">
                    <div class="carousel-card-info  text-black">
                        <h5>Rahul Rajput</h5>
                    </div>
                </div>
            </label> -->
        </div>

    </div>

</div>