function modal() {
    document.getElementById('id01').style.display = 'block';
}